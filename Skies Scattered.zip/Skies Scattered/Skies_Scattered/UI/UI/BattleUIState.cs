
using System.Collections.Generic;

namespace Skies_Scattered.UI
{
    public class BattleUIState
    {
        public string TopMessage { get; set; } = "Here They Are";

        public List<CharacterStats> PartyMembers { get; set; } =
            new List<CharacterStats>();

        public List<string> CurrentMenuOptions { get; set; } =
            new List<string>
            {
                "SPELL",
                "Z-SPELL",
                "ACT",
                "DEFEND",
                "RUN"
            };

        public int SelectedOptionIndex { get; set; } = 0;

        public int CurrentPartyMemberIndex { get; set; } = 0;

        public bool IsActionMenuOpen { get; set; } = false;

        public bool IsSelectingTarget { get; set; } = false;

        public bool IsSpellMenuOpen { get; set; } = false;

        public int SelectedSpellIndex { get; set; } = 0;

        public int SelectedEnemyIndex { get; set; } = 0;
    }

    public class CharacterStats
    {
        public string Name { get; set; }

        public int HP { get; set; }

        public int AP { get; set; }

        public int CT { get; set; }

        public int PP { get; set; }

        public int MaxPP { get; set; }

        public List<string> Spells { get; set; } =
            new List<string>();
    }
}
